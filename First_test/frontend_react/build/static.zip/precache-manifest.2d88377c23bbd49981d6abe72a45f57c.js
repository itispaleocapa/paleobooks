self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "25f852a92aaa4cacc940a9c31bc35273",
    "url": "/index.html"
  },
  {
    "revision": "73a7bc7a962e14ab422f",
    "url": "/static/css/main.6571ea14.chunk.css"
  },
  {
    "revision": "ca9835972d6dac3bf842",
    "url": "/static/js/2.f2bb21fa.chunk.js"
  },
  {
    "revision": "fdb2bbbbb647ba518ef54493c5cba538",
    "url": "/static/js/2.f2bb21fa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "73a7bc7a962e14ab422f",
    "url": "/static/js/main.114bcf39.chunk.js"
  },
  {
    "revision": "605e7409e7213c4551c7",
    "url": "/static/js/runtime-main.cd57d020.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);