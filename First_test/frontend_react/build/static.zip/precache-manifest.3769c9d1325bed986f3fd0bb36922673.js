self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f85e90b3acadb3500df225f262c3c663",
    "url": "/index.html"
  },
  {
    "revision": "f547a2eb13d264c43257",
    "url": "/static/css/main.6571ea14.chunk.css"
  },
  {
    "revision": "ca9835972d6dac3bf842",
    "url": "/static/js/2.f2bb21fa.chunk.js"
  },
  {
    "revision": "fdb2bbbbb647ba518ef54493c5cba538",
    "url": "/static/js/2.f2bb21fa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f547a2eb13d264c43257",
    "url": "/static/js/main.c8f81e81.chunk.js"
  },
  {
    "revision": "605e7409e7213c4551c7",
    "url": "/static/js/runtime-main.cd57d020.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);